import type { Vector3 } from "../math";

export type Change =
  | ForceMovementStateChange
  | ObserveChange
  | InterruptChange
  | NoOpChange;

export interface ForceMovementStateChange {
  type: "forceMovementState";
  state: "dashing";
  direction: Vector3;
  priority: HandlerTier;
}

export interface ObserveChange {
  type: "observe";
  key: string;
  value: unknown;
  priority: HandlerTier;
}

export interface InterruptChange {
  type: "interrupt";
  reason: string;
  priority: HandlerTier;
}

export interface NoOpChange {
  type: "noop";
  priority: HandlerTier;
}

export const HANDLER_TIERS = ["reflexive", "tactical", "observational"] as const;
export type HandlerTier = (typeof HANDLER_TIERS)[number];

export function tierRank(t: HandlerTier): number {
  return HANDLER_TIERS.indexOf(t);
}
