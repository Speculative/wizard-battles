import type { Contestant } from "../contestants/contestant";
import type { World } from "../world";
import type { RosterEntry, Tactic } from "./tactic";

const EVAL_INTERVAL = 1.0;
const RANDOM_JITTER = 0.35;

export class TacticSelector {
  private readonly roster: RosterEntry[];
  private readonly label: string;
  private current: Tactic;
  private dwellLeft: number;
  private evalTimer = 0;
  private lastPhaseId: string | undefined;

  constructor(roster: RosterEntry[], label = "?") {
    if (roster.length === 0) {
      throw new Error("TacticSelector requires at least one roster entry");
    }
    this.roster = roster.map(entry => ({ ...entry }));
    this.label = label;
    this.current = roster[0].tactic;
    this.dwellLeft = this.current.minDwell;
    this.lastPhaseId = this.current.currentPhaseId?.();
  }

  get currentTactic(): Tactic {
    return this.current;
  }

  updateDormantObservations(self: Contestant, world: World): void {
    for (const entry of this.roster) {
      const tactic = entry.tactic;
      if (tactic === this.current) continue;
      if (!tactic.detectors || !tactic.onObserve) continue;
      const handlers = tactic.handlers ?? [];
      for (const detector of tactic.detectors) {
        const event = detector.detect(self, world);
        if (!event) continue;
        for (const handler of handlers) {
          if (handler.eventId !== event.id) continue;
          const produced = handler.handle(self, event, world);
          for (const c of produced) {
            if (c.type === "observe") {
              tactic.onObserve(c.key, c.value, world);
            }
          }
          if (handler.terminal) break;
        }
      }
    }
  }

  forceRescore(self: Contestant, world: World, reason: string): void {
    world.emit("interrupt", this.label, { reason, currentTactic: this.current.id });
    this.rescore(self, world);
  }

  update(dt: number, self: Contestant, world: World): void {
    this.dwellLeft -= dt;
    this.evalTimer -= dt;
    if (this.evalTimer <= 0 && this.dwellLeft <= 0) {
      this.rescore(self, world);
    }

    const phaseId = this.current.currentPhaseId?.();
    if (phaseId !== this.lastPhaseId) {
      world.emit("tactic_phase", this.label, {
        tactic: this.current.id,
        from: this.lastPhaseId ?? null,
        to: phaseId ?? null,
      });
      this.lastPhaseId = phaseId;
    }
  }

  private rescore(self: Contestant, world: World): void {
    this.evalTimer = EVAL_INTERVAL;
    let best = this.current;
    let bestScore = -Infinity;
    for (const entry of this.roster) {
      const raw = entry.tactic.score(self, world);
      const jitter = 1 + (world.random() * 2 - 1) * RANDOM_JITTER;
      const score = raw * entry.bias * jitter;
      if (score > bestScore) {
        bestScore = score;
        best = entry.tactic;
      }
    }
    if (best !== this.current) {
      const prev = this.current.id;
      this.current = best;
      this.dwellLeft = best.minDwell;
      this.lastPhaseId = best.currentPhaseId?.();
        world.emit("tactic_switch", this.label, {
        from: prev,
        to: best.id,
        score: bestScore,
      });
    } else {
      this.dwellLeft = best.minDwell;
    }
  }
}
